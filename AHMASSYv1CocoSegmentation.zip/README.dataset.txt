# AHM_ASSY > 2024-11-13 9:14pm
https://universe.roboflow.com/kun-project/ahm_assy

Provided by a Roboflow user
License: CC BY 4.0

